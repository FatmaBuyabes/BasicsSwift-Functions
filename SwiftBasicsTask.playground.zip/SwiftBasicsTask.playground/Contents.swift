import UIKit
//part 1
var name = "Fatma Buyabes"
var age = 23
var gpa = 3.41

print("My name is ",name,", I am ",age," years old , My GPA is ",gpa)

// part 2
var numericString = "10"
var numericDouble = Double(numericString)
var numericInt = Int(numericString)

print("As an Int: ",numericInt," As a Double: ",numericDouble)

var ageInt = Double(age)
var gpaInt = Int(gpa)

print("Age: ",ageInt, "GPA: ",gpaInt)

// part 3
var isStudent = false

print("Is a student: ",isStudent)

// part 4
if 13 <= age && age <= 19 {
    print("I am Teenager")
}else{
    print("I am not a teenager")
}

if   age <= 18 || age >= 65 {
    print("You are eligible for discount")
}else{
    "Sorry! Not eligiable for discount"
}

//Functions Task
//Exercise 1
func isShorterOrEqualThanFive(text:String ) -> Bool{
    print(text.count)
    if text.count <= 5{
        return true
    }else{
        return false
    }
    
}
isShorterOrEqualThanFive(text: "Fatma")

//Exercise 2
func convertToCelsius(fahrenheit:Double) -> Double{
    let celisus = (fahrenheit - 32)*5/9
    return celisus
}
convertToCelsius(fahrenheit: 112.0)










